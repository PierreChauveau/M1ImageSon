# Android NDK

Test script to build `tinyexr` with Android NDK r10.
Just checks compilation on Android NDK.
